import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, Flag, Gauge, Trophy, Wrench } from "lucide-react";
import { GameShell } from "@/components/game/GameShell";
import { StatBar } from "@/components/game/StatBar";
import { player, tracks } from "@/lib/game-data";
import { useGame } from "@/lib/game-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PROJECT RUSH — Futuristic Mobile Racing" },
      { name: "description", content: "PROJECT RUSH lobby: pick your hypercar or hoverbike, tune your HUD and hit the neon grid." },
      { property: "og:title", content: "PROJECT RUSH — Futuristic Mobile Racing" },
      { property: "og:description", content: "Neon night circuits, ranked online grids and deep vehicle customization." },
    ],
  }),
  component: Lobby,
});

function Lobby() {
  const { vehicle } = useGame();
  const featured = tracks[0]!;

  return (
    <GameShell>
      <section className="animate-rise">
        <div className="relative overflow-hidden rounded-3xl glass p-4">
          <div className="absolute -left-10 top-6 h-40 w-40 rounded-full bg-primary/25 blur-3xl" />
          <div className="absolute -right-10 bottom-0 h-40 w-40 rounded-full bg-accent/25 blur-3xl" />
          <div className="relative flex items-center justify-between">
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-[0.3em] text-primary">Active build</p>
              <h1 className="truncate font-display text-2xl font-black text-glow">{vehicle.name}</h1>
              <p className="truncate text-xs text-muted-foreground">{vehicle.brand} · {vehicle.tier} class</p>
            </div>
            <span className="shrink-0 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 font-display text-[10px] font-bold tracking-widest text-primary">
              LVL {player.level}
            </span>
          </div>
          <div className="relative mt-2 h-44">
            <div className="absolute inset-x-6 bottom-4 h-8 rounded-[100%] bg-primary/25 blur-2xl animate-pulse-glow" />
            <img src={vehicle.image} alt={vehicle.name} width={1280} height={768}
              className="relative h-full w-full animate-float object-contain drop-shadow-[0_18px_45px_oklch(0.82_0.16_195_/_0.35)]" />
            <div className="pointer-events-none absolute inset-0 overflow-hidden">
              <div className="h-full w-16 animate-scan bg-gradient-to-r from-transparent via-primary/15 to-transparent" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-2">
            <StatBar label="Speed" value={vehicle.stats.speed} />
            <StatBar label="Accel" value={vehicle.stats.accel} />
            <StatBar label="Handling" value={vehicle.stats.handling} accent />
            <StatBar label="Nitro" value={vehicle.stats.nitro} accent />
          </div>
        </div>
      </section>
      <Link to="/race" className="mt-4 flex items-center justify-between overflow-hidden rounded-2xl border border-primary/50 bg-gradient-to-r from-primary/25 via-primary/10 to-accent/25 px-5 py-4 transition-transform active:scale-[0.98]">
        <span className="flex items-center gap-3"><Flag className="h-5 w-5 text-primary" /><span className="font-display text-lg font-black tracking-[0.15em] text-glow">RACE NOW</span></span>
        <ChevronRight className="h-5 w-5 text-primary" />
      </Link>
      <div className="mt-4 grid grid-cols-3 gap-3">
        <QuickTile to="/garage" icon={<Gauge className="h-4 w-4" />} label="Garage" sub="6 units" />
        <QuickTile to="/customize" icon={<Wrench className="h-4 w-4" />} label="Custom" sub="5 cats" />
        <QuickTile to="/profile" icon={<Trophy className="h-4 w-4" />} label="Profile" sub={player.rank} />
      </div>
      <div className="mt-4 rounded-2xl glass p-4">
        <div className="flex items-center justify-between">
          <p className="text-[10px] uppercase tracking-[0.3em] text-accent">Featured circuit</p>
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{featured.weather}</span>
        </div>
        <h2 className="mt-1 font-display text-lg font-black">{featured.name}</h2>
        <p className="text-xs text-muted-foreground">{featured.laps} laps · {featured.length} · Season 4 rotation</p>
        <Link to="/hud" className="mt-3 inline-flex items-center gap-2 rounded-xl border border-border bg-surface/60 px-3 py-2 font-display text-[11px] font-bold tracking-widest text-primary transition-transform active:scale-95">
          EDIT HUD LAYOUT <ChevronRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </GameShell>
  );
}

function QuickTile({to, icon, label, sub}: {to: string; icon: React.ReactNode; label: string; sub: string}) {
  return (
    <Link to={to as "/"} className="flex flex-col gap-1 rounded-2xl glass p-3 transition-transform active:scale-95">
      <span className="text-primary">{icon}</span>
      <span className="font-display text-xs font-bold tracking-widest">{label}</span>
      <span className="truncate text-[10px] text-muted-foreground">{sub}</span>
    </Link>
  );
}