import { Link } from "@tanstack/react-router";
import { Bike, Flag, Home, Paintbrush, Settings, Users, Zap, ChevronLeft } from "lucide-react";
import type { ReactNode } from "react";
import trackBg from "@/assets/track-bg.jpg";
import { player } from "@/lib/game-data";
import { cn } from "@/lib/utils";

const tabs = [
  { to: "/", label: "Lobby", icon: Home }, { to: "/garage", label: "Garage", icon: Bike },
  { to: "/race", label: "Race", icon: Flag }, { to: "/customize", label: "Custom", icon: Paintbrush },
  { to: "/friends", label: "Friends", icon: Users },
] as const;

export function GameShell({ children, title, back }: { children: ReactNode; title?: string; back?: string }) {
  return <div className="relative min-h-screen overflow-hidden bg-background">
    <img src={trackBg} alt="" aria-hidden loading="lazy" className="pointer-events-none fixed inset-0 h-full w-full object-cover opacity-25" />
    <div className="pointer-events-none fixed inset-0 bg-gradient-to-b from-background/60 via-background/85 to-background" />
    <div className="pointer-events-none fixed inset-x-0 bottom-0 h-72 grid-floor" />
    <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col">
      <TopBar title={title} back={back} /><main className="flex-1 px-4 pb-28 pt-2">{children}</main><BottomNav />
    </div>
  </div>;
}

function TopBar({ title, back }: { title?: string; back?: string }) {
  return <header className="sticky top-0 z-20 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-border/60 bg-background/70 px-4 py-3 backdrop-blur-xl">
    <div className="flex min-w-0 items-center gap-2">
      {back ? <Link to={back as "/"} className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-border bg-surface/70 text-primary" aria-label="Back"><ChevronLeft className="h-5 w-5" /></Link>
        : <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl neon-edge bg-surface/70"><Zap className="h-4 w-4 text-primary" /></div>}
      <div className="min-w-0"><p className="truncate font-display text-sm font-black tracking-[0.18em] text-foreground text-glow">{title ?? "PROJECT RUSH"}</p><p className="truncate text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{player.name} {player.tag}</p></div>
    </div>
    <div className="flex shrink-0 items-center gap-2">
      <Chip value={`${(player.credits / 1000).toFixed(1)}K`} label="CR" /><Chip value={String(player.tokens)} label="RT" accent />
      <Link to="/settings" className="grid h-9 w-9 place-items-center rounded-xl border border-border bg-surface/70 text-muted-foreground" aria-label="Settings"><Settings className="h-4 w-4" /></Link>
    </div>
  </header>;
}
function Chip({ value, label, accent }: { value: string; label: string; accent?: boolean }) {
  return <div className={cn("clip-slant rounded-md border px-2 py-1 text-right leading-none", accent ? "border-accent/40 bg-accent/10" : "border-primary/30 bg-primary/10")}>
    <span className={cn("font-display text-[11px] font-bold", accent ? "text-accent" : "text-primary")}>{value}</span>
    <span className="ml-1 text-[9px] tracking-widest text-muted-foreground">{label}</span>
  </div>;
}
function BottomNav() {
  return <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-md border-t border-border/60 bg-background/85 px-2 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl"><ul className="grid grid-cols-5">
    {tabs.map(({ to, label, icon: Icon }) => <li key={to}><Link to={to as "/"} activeOptions={{ exact: to === "/" }} className="group flex flex-col items-center gap-1 py-2.5 text-muted-foreground transition-colors data-[status=active]:text-primary"><span className="relative grid h-9 w-9 place-items-center rounded-xl"><Icon className="h-[18px] w-[18px]" /></span><span className="font-display text-[9px] font-bold uppercase tracking-[0.14em]">{label}</span></Link></li>)}
  </ul></nav>;
}