export function StatBar({ label, value, accent }: { label: string; value: number; accent?: boolean }) {
  return <div className="space-y-1">
    <div className="flex items-center justify-between text-[10px] uppercase tracking-[0.2em] text-muted-foreground"><span>{label}</span><span className="font-display font-bold text-foreground">{value}</span></div>
    <div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full transition-[width] duration-700 ease-out" style={{ width: `${value}%`, background: accent ? "linear-gradient(90deg, var(--hot), var(--neon))" : "linear-gradient(90deg, var(--neon), var(--hot))" }} /></div>
  </div>;
}