import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { defaultHud, vehicles, type HudElement, type Vehicle } from "./game-data";

type GameState = {
  selectedVehicleId: string;
  selectVehicle: (id: string) => void;
  vehicle: Vehicle;
  difficulty: string;
  setDifficulty: (id: string) => void;
  hud: HudElement[];
  setHud: (next: HudElement[]) => void;
};

const GameContext = createContext<GameState | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [selectedVehicleId, selectVehicle] = useState(vehicles[0]!.id);
  const [difficulty, setDifficulty] = useState("normal");
  const [hud, setHud] = useState<HudElement[]>(defaultHud);

  const value = useMemo<GameState>(
    () => ({
      selectedVehicleId,
      selectVehicle,
      vehicle: vehicles.find((v) => v.id === selectedVehicleId) ?? vehicles[0]!,
      difficulty,
      setDifficulty,
      hud,
      setHud,
    }),
    [selectedVehicleId, difficulty, hud],
  );

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error("useGame must be used inside GameProvider");
  return ctx;
}