# PROJECT RUSH backup

This is a manually downloadable source snapshot from the Lovable prototype at commit:
`5250ce6f7e1e090433a055e437cb930ea31550c5`

Included: package configuration, core game state/data, lobby, shell, stat bars, router/start files, and the main design stylesheet.

Not included: binary assets (`car-hero.png`, `bike-hero.png`, `track-bg.jpg`, favicon) and the many generated shadcn/Radix UI component files. This is therefore a CORE SOURCE BACKUP, not a complete export.

The known runtime error is:
`useGame must be used inside GameProvider`

Current `src/routes/__root.tsx` preserves the original provider bug so this backup matches the captured project. The intended fix is to wrap `<Outlet />` with `<GameProvider>`.

For a complete backup, use Lovable's GitHub/export integration when available.
